from django.contrib import admin
from django.conf.urls import url
from django.conf.urls import include, url

urlpatterns = [
    url('admin/', admin.site.urls),
    url(r'^', include('app1.urls')),
]
