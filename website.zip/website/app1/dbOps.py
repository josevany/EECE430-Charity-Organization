from .models import Contributor, Event, Donation


def getAllContributors():
    return Contributor.objects.all()

def getAllEvents():
    return Event.objects.all()

def getAllDonations():
    return Donation.objects.all()

def addContributor(contributorName):
    Contributor.objects.create(Contributor_name=contributorName)
    return True

def addEvent(eventName):
    Event.objects.create(Event_name=eventName)
    return True

def addDonation(contributorId, eventId, donationAmount):
    Donation.objects.create(Contributor_id=contributorId, Event_id=eventId, Amount=donationAmount)
    return True

def getContributorIdByName(contributorName):
    return Contributor.objects.filter(Contributor_name=contributorName).first()

def getEventIdByName(eventName):
    return Event.objects.filter(Event_name=eventName).first()

def getContributorById(contributorId):
    return Contributor.objects.filter(Contributor_id=contributorId).first()

def getEventById(eventId):
    return Event.objects.filter(Event_id=eventId).first()

def getDonationById(donationId):
    return Donation.objects.filter(Donation_id=donationId).first()

def updateContributor(contributorId, contributorName):
    contributor = Contributor.objects.get(Contributor_id=contributorId)
    contributor.Contributor_name = contributorName
    contributor.save()
    return True

def updateEvent(eventId, eventName):
    event = Event.objects.get(Event_id=eventId)
    event.Event_name = eventName
    event.save()
    return True

def updateDonation(donationId, eventId, contributorId, donationAmount):
    donation = Donation.objects.get(Donation_id=donationId)
    donation.Event_id = eventId
    donation.Contributor_id = contributorId
    donation.Amount = donationAmount
    donation.save()
    return True

def removeContributor(contributorId):
    donations = Donation.objects.filter(Contributor_id=contributorId)
    donations.delete()
    contributor = Contributor.objects.get(Contributor_id=contributorId)
    contributor.delete()
    return True

def removeEvent(eventId):
    donations = Donation.objects.filter(Event_id=eventId)
    donations.delete()
    event = Event.objects.get(Event_id=eventId)
    event.delete()
    return True

def removeDonation(donationId):
    donation = Donation.objects.get(Donation_id=donationId)
    donation.delete()
    return True
