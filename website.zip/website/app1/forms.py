from django.forms import ModelForm
from .models import Contributor, Event, Donation
from django import forms


class CreateContributorForm(ModelForm):
    class Meta:
        model = Contributor
        fields = ['Contributor_id', 'Contributor_name']


class CreateEventForm(ModelForm):
    class Meta:
        model = Event
        fields = ['Event_id', 'Event_name']


class CreateDonationForm(ModelForm):
    class Meta:
        model = Donation
        fields = '__all__'
        
class EditContributorForm(ModelForm):
    class Meta:
        model = Contributor
        fields = '__all__'


class EditEventForm(ModelForm):
    class Meta:
        model = Event
        fields = '__all__'


class EditDonationForm(ModelForm):
    class Meta:
        model = Donation
        fields = '__all__'
        
class UpdayteDonationForm(forms.Form):
    Contributor_id = forms.ModelChoiceField(queryset=Contributor.objects.all().values_list('Contributor_name', flat=True))
    Event_id = forms.ModelChoiceField(queryset=Event.objects.all().values_list('Event_name', flat=True))
    Amount = forms.IntegerField()
    
    def clean(self):
        cleaned_data = super(AddDonationForm, self).clean()
        Contributor_id = cleaned_data.get('Contributor_id')
        Event_id = cleaned_data.get('Event_id')
        Amount = cleaned_data.get('Amount')
        if not Contributor_id and not Event_id and not Amount:
            raise forms.ValidationError('You have to write something!')
    
class AddDonationForm(forms.Form):
    Contributor_id = forms.ModelChoiceField(queryset=Contributor.objects.all().values_list('Contributor_name', flat=True))
    Event_id = forms.ModelChoiceField(queryset=Event.objects.all().values_list('Event_name', flat=True))
    Amount = forms.IntegerField()
    
    def clean(self):
        cleaned_data = super(AddDonationForm, self).clean()
        Contributor_id = cleaned_data.get('Contributor_id')
        Event_id = cleaned_data.get('Event_id')
        Amount = cleaned_data.get('Amount')
        if not Contributor_id and not Event_id and not Amount:
            raise forms.ValidationError('You have to write something!')

class ListContributorsForm(forms.Form):
    Contributor_id = forms.IntegerField()


class ListEventsForm(forms.Form):
    Event_id = forms.IntegerField()


class MoneyDonatedInEventsForm(forms.Form):
    Event_id = forms.IntegerField()
