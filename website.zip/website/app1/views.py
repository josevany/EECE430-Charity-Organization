from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
from .forms import *
from .dbOps import *

def redirect_administrator(request):
    return redirect('posts_list_url', permanent=True)

def index(request):
    return render(request, 'index.html')


def team(request):
    return render(request, 'team.html')


def about(request):
    return render(request, 'about.html')


def editContributor(request, id):
    if request.method == 'POST':
        form = EditContributorForm(request.POST)
        if form.is_valid():
            contributor_form = form.cleaned_data
            contributor_name = contributor_form['Contributor_name']
            updateContributor(id, contributor_form['Contributor_name'])
        return redirect('/administrator')
    else:
        form = EditContributorForm()
        contributor = getContributorById(id)
        return render(request, 'editContributor.html', {'form': form, 'contributor': contributor})


def editEvent(request, id):
    if request.method == 'POST':
        form = EditEventForm(request.POST)
        if form.is_valid():
            event_form = form.cleaned_data
            event_name = event_form['Event_name']
            updateEvent(id, event_form['Event_name'])
        return redirect('/administrator')
    else:
        form = EditEventForm()
        event = getEventById(id)
        return render(request, 'editEvent.html', {'form': form, 'event': event})


def editDonation(request, id):
    contributorName = str(request.POST.get('Contributor_id', ""))
    eventName = str(request.POST.get('Event_id', ""))
    if request.method == 'POST':
        contributorID = getContributorIdByName(contributorName)
        eventID = getEventIdByName(eventName)
        amount = request.POST.get('Amount', "")
        updateDonation(id, eventID, contributorID, amount)
        return redirect('/administrator')
    else:
        form = AddDonationForm()
        donation = getDonationById(id)
        return render(request, 'editDonation.html', {'form': form, 'donation': donation})


def deleteContributor(request, id):
    removeContributor(id)
    return redirect('/administrator')


def deleteEvent(request, id):
    removeEvent(id)
    return redirect('/administrator')


def deleteDonation(request, id):
    removeDonation(id)
    return redirect('/administrator')


def administrator(request):
    contributors = getAllContributors()
    events = getAllEvents()
    donations = getAllDonations()
    return render(request, 'administrator.html', {'contributors': contributors, 'events': events, 'donations': donations})


def add_contributor(request):
    if request.method == 'POST':
        form = CreateContributorForm(request.POST)
        if form.is_valid():
            contributor_form = form.cleaned_data
            contributor_name = contributor_form['Contributor_name']
            addContributor(contributor_name)
            return render(request, 'index.html')
    else:
        form = CreateContributorForm()
    contributors = getAllContributors()
    donations = getAllDonations()
    donationsPerContributor = {}
    for contr in contributors:
        donationsPerContributor[contr.Contributor_id] = 0
    for donation in donations:
        donationsPerContributor[donation.Contributor_id.Contributor_id] += donation.Amount
    return render(request, 'add_contributor.html', {'form': form, 'contributors': contributors, 'donations': donations, 'donationsPerContributor': donationsPerContributor})


def add_event(request):
    donationsByEvent = {}
    donationsCountByEvent = {}
    events = getAllEvents()
    donations = getAllDonations()

    for event in events:
        donationsByEvent[event.Event_id] = 0
        donationsCountByEvent[event.Event_id] = 0
    for donation in donations:
        donationsByEvent[donation.Event_id.Event_id] += donation.Amount
        donationsCountByEvent[donation.Event_id.Event_id] += 1

    if request.method == 'POST':
        form = CreateEventForm(request.POST)
        if form.is_valid():
            event_form = form.cleaned_data
            event_name = event_form['Event_name']
            addEvent(event_name)
            return render(request, 'index.html')
    else:
        form = CreateEventForm()
    return render(request, 'add_event.html', {'form': form, 'events': events, 'donationsByEvent': donationsByEvent, 'donationsCountByEvent': donationsCountByEvent})


def add_donation(request):
    contributorName = str(request.POST.get('Contributor_id', ""))
    eventName = str(request.POST.get('Event_id', ""))
    if request.method == 'POST':
        contributorID = getContributorIdByName(contributorName)
        eventID = getEventIdByName(eventName)
        amount = request.POST.get('Amount', "")
        addDonation(contributorID, eventID, amount)
        return render(request, 'index.html')
    else:
        form = AddDonationForm()
    return render(request, 'add_donation.html', {'form': form})


def contributors_report(request):
    if request.method == 'POST':
        form = ListContributorsForm(request.POST)

        if form.is_valid():
            contributor_form = form.cleaned_data
            contributor_id = contributor_form['Contributor_id']

            result = ''

            for contributor in getAllContributors():
                if contributor.Contributor_id == contributor_id:
                    result = contributor

            contributor_donations = []
            events = []
            total = 0
            for donation in getAllDonations():
                if donation.Contributor_id.Contributor_id == contributor_id:
                    total += donation.Amount
                    if donation.Event_id not in events:
                        events.append(donation.Event_id)
                        contributor_donations.append(
                            [donation.Event_id.Event_name, donation.Amount])
                    else:
                        i = events.index(donation.Event_id)
                        contributor_donations[i][1] += donation.Amount

            return render(request, 'contributors_report.html', {'form': form, 'result': result, 'donation': contributor_donations, 'total': total})

    else:
        form = ListContributorsForm()
    return render(request, 'contributors_report.html', {'form': form})


def events_report(request):
    if request.method == 'POST':
        form = ListEventsForm(request.POST)

        if form.is_valid():
            events_form = form.cleaned_data
            event_id = events_form['Event_id']

            result = ''

            for event in getAllEvents():
                if event.Event_id == event_id:
                    result = event
            return render(request, 'events_report.html', {'form': form, 'result': result})

    else:
        form = ListEventsForm()
    return render(request, 'events_report.html', {'form': form})


def money_donated_in_event_report(request):
    if request.method == 'POST':
        form = MoneyDonatedInEventsForm(request.POST)

        if form.is_valid():
            events_form = form.cleaned_data
            event_id = events_form['Event_id']

            result = ''

            for event in getAllEvents():
                if event.Event_id == event_id:
                    result = event

            event_donations = []
            contributors = []
            total = 0
            for donation in getAllDonations():
                if donation.Event_id.Event_id == event_id:
                    total += donation.Amount
                    if donation.Contributor_id not in contributors:
                        contributors.append(donation.Contributor_id)
                        event_donations.append(
                            [donation.Contributor_id.Contributor_name, donation.Amount])

                    else:
                        i = contributors.index(donation.Contributor_id)
                        event_donations[i][1] += donation.Amount

            return render(request, 'money_donated_report.html', {'form': form, 'result': result, 'donation': event_donations, 'total': total})

    else:
        form = MoneyDonatedInEventsForm()
    return render(request, 'money_donated_report.html', {'form': form})
