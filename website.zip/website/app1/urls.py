from django.conf.urls import url
from . import views


urlpatterns = [
    url(r'^$', views.index),
    url(r'^add_contributor', views.add_contributor),
    url(r'^add_event', views.add_event),
    url(r'^add_donation', views.add_donation),
    url(r'^contributors_report', views.contributors_report),
    url(r'^events_report', views.events_report),
    url(r'^money_donated_report', views.money_donated_in_event_report),
    url(r'^team', views.team),
    url(r'^about', views.about),
    url(r'^administrator', views.administrator),
    url(r'^editContributor/(?P<id>[0-9]+)/$', views.editContributor),
    url(r'^deleteContributor/(?P<id>[0-9]+)/$', views.deleteContributor),
    url(r'^editEvent/(?P<id>[0-9]+)/$', views.editEvent),
    url(r'^deleteEvent/(?P<id>[0-9]+)/$', views.deleteEvent),
    url(r'^editDonation/(?P<id>[0-9]+)/$', views.editDonation),
    url(r'^deleteDonation/(?P<id>[0-9]+)/$', views.deleteDonation)
]
