from django.db import models


class Contributor(models.Model):
    Contributor_id = models.AutoField(primary_key=True)
    Contributor_name = models.CharField(max_length=30)
    
    def __unicode__(self):
        return self.Contributor_name


class Event(models.Model):
    Event_id = models.AutoField(primary_key=True)
    Event_name = models.CharField(max_length=100)
    #Event_amount = models.IntegerField(default = 0)

    def __unicode__(self):
        return self.Event_name

class Donation(models.Model):
    Donation_id = models.AutoField(primary_key=True)
    Contributor_id = models.ForeignKey(Contributor, on_delete=models.CASCADE)
    Event_id = models.ForeignKey(Event, on_delete=models.CASCADE)
    Amount = models.IntegerField()
    
    def __unicode__(self):
        return self.Amount
